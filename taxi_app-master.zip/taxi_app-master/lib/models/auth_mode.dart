enum AuthMode {
  login,
  signup,
}
