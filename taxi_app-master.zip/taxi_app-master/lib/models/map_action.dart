enum MapAction {
  selectTrip,
  tripSelected,
  searchDriver,
  driverArriving,
  driverArrived,
  tripStarted,
  reachedDestination,
}
